const WEBHOOK_URL = "https://k1000o.app.n8n.cloud/webhook/growth-analysis";

// Contexto embebido para que n8n actúe como Senior Growth Manager.
const SYSTEM_PROMPT = [
  "Actúa como un Senior Growth Manager.",
  "Analiza los datos del dashboard de ventas con foco en clicks, conversiones y ventas.",
  "Devuelve exactamente 3 acciones inmediatas, concretas y priorizadas para mejorar resultados.",
  "Usa un tono profesional, directo y orientado a negocio.",
  "Si faltan datos, indica supuestos mínimos y sigue proponiendo acciones accionables."
].join(" ");

const analyzeBtn = document.getElementById("analyzeBtn");
const statusEl = document.getElementById("status");
const resultEl = document.getElementById("result");

function setStatus(message, isError = false) {
  statusEl.textContent = message;
  statusEl.classList.toggle("error", isError);
}

function setResult(message) {
  resultEl.innerHTML = renderMarkdown(message);
}

function formatResponse(payload) {
  if (payload == null) {
    return "Sin respuesta del webhook.";
  }

  if (typeof payload === "string") {
    return payload.trim();
  }

  if (typeof payload === "object") {
    if (typeof payload.output === "string") {
      return payload.output.trim();
    }

    if (typeof payload.data === "string") {
      return payload.data.trim();
    }

    if (payload.data && typeof payload.data === "object") {
      if (typeof payload.data.output === "string") {
        return payload.data.output.trim();
      }

      if (typeof payload.data.data === "string") {
        return payload.data.data.trim();
      }

      return JSON.stringify(payload.data, null, 2);
    }

    if (typeof payload.result === "string") {
      return payload.result.trim();
    }

    return JSON.stringify(payload, null, 2);
  }

  return String(payload);
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function renderInlineMarkdown(text) {
  const safeText = escapeHtml(text);

  return safeText
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>");
}

function renderMarkdown(markdown) {
  const text = String(markdown || "").trim();
  if (!text) {
    return "";
  }

  const lines = text.split(/\r?\n/);
  const blocks = [];
  let currentList = null;
  let inCodeBlock = false;
  let codeBuffer = [];

  const flushList = () => {
    if (!currentList) return;
    const tag = currentList.type === "ol" ? "ol" : "ul";
    blocks.push(`<${tag}>${currentList.items.join("")}</${tag}>`);
    currentList = null;
  };

  const flushCode = () => {
    if (!inCodeBlock) return;
    blocks.push(`<pre><code>${escapeHtml(codeBuffer.join("\n"))}</code></pre>`);
    codeBuffer = [];
    inCodeBlock = false;
  };

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();

    if (line.startsWith("```")) {
      if (inCodeBlock) {
        flushCode();
      } else {
        flushList();
        inCodeBlock = true;
        codeBuffer = [];
      }
      continue;
    }

    if (inCodeBlock) {
      codeBuffer.push(rawLine);
      continue;
    }

    const headingMatch = line.match(/^(#{1,3})\s+(.*)$/);
    if (headingMatch) {
      flushList();
      const level = headingMatch[1].length;
      blocks.push(
        `<h${level}>${renderInlineMarkdown(headingMatch[2].trim())}</h${level}>`
      );
      continue;
    }

    const bulletMatch = line.match(/^[-*]\s+(.*)$/);
    if (bulletMatch) {
      if (!currentList || currentList.type !== "ul") {
        flushList();
        currentList = { type: "ul", items: [] };
      }
      currentList.items.push(`<li>${renderInlineMarkdown(bulletMatch[1].trim())}</li>`);
      continue;
    }

    const numberedMatch = line.match(/^\d+\.\s+(.*)$/);
    if (numberedMatch) {
      if (!currentList || currentList.type !== "ol") {
        flushList();
        currentList = { type: "ol", items: [] };
      }
      currentList.items.push(`<li>${renderInlineMarkdown(numberedMatch[1].trim())}</li>`);
      continue;
    }

    if (line.startsWith("> ")) {
      flushList();
      blocks.push(`<blockquote>${renderInlineMarkdown(line.slice(2).trim())}</blockquote>`);
      continue;
    }

    if (!line.trim()) {
      flushList();
      continue;
    }

    flushList();
    blocks.push(`<p>${renderInlineMarkdown(line.trim())}</p>`);
  }

  flushList();
  flushCode();

  return blocks.join("\n");
}

function getActiveTab() {
  return new Promise((resolve, reject) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs && tabs[0];
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!tab || typeof tab.id !== "number") {
        reject(new Error("No se encontró una pestaña activa."));
        return;
      }
      resolve(tab);
    });
  });
}

function injectDashboardExtractor(tabId) {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript(
      {
        target: { tabId },
        files: ["content.js"]
      },
      () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve();
      }
    );
  });
}

function runDashboardExtractor(tabId) {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript(
      {
        target: { tabId },
        func: () => {
          if (typeof window.__growthManagerExtractDashboard === "function") {
            return window.__growthManagerExtractDashboard();
          }

          return {
            pageTitle: document.title || "",
            pageUrl: window.location.href,
            extractedText: (document.body && document.body.innerText) || ""
          };
        }
      },
      (results) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        const extracted = results && results[0] ? results[0].result : null;
        if (!extracted || !extracted.extractedText) {
          reject(new Error("No fue posible extraer datos del dashboard."));
          return;
        }

        resolve(extracted);
      }
    );
  });
}

async function sendToWebhook(dashboardData) {
  const response = await fetch(WEBHOOK_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      systemPrompt: SYSTEM_PROMPT,
      source: "growth-manager-connector",
      dashboard: dashboardData
    })
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => "");
    throw new Error(
      `El webhook respondió con error HTTP ${response.status}. ${errorText}`.trim()
    );
  }

  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return response.json();
  }

  return response.text();
}

analyzeBtn.addEventListener("click", async () => {
  analyzeBtn.disabled = true;
  setStatus("Analizando...");
  setResult("");

  try {
    const tab = await getActiveTab();
    await injectDashboardExtractor(tab.id);
    const dashboardData = await runDashboardExtractor(tab.id);

    setStatus("Enviando datos al Growth Manager...");
    const webhookResponse = await sendToWebhook(dashboardData);

    setStatus("Análisis completado.");
    setResult(formatResponse(webhookResponse));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Error desconocido.";
    setStatus(`Error: ${message}`, true);
    setResult(
      [
        "# Error",
        "",
        "No se pudo completar el análisis.",
        "",
        `- ${message}`
      ].join("\n")
    );
  } finally {
    analyzeBtn.disabled = false;
  }
});
